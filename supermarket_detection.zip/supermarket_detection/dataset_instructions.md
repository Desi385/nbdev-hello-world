
        # Dataset Download Instructions
        
        ## 1. SKU110K Dataset
        - Download from: https://github.com/eg4000/SKU110K_CVPR19
        - Contains 11,762 images with 1.7M bounding box annotations
        - Focused on densely packed retail products
        
        ## 2. Retail Product Checkout (RPC) Dataset  
        - Download from: https://rpc-dataset.github.io/
        - Contains 83,739 images with 200 product categories
        - Focused on checkout scenarios
        
        ## 3. OpenImages Retail Subset
        - Use OpenImages API to download retail-related categories
        - Categories: bottle, can, package, box, etc.
        
        ## 4. Custom Data Collection
        - Collect images from your specific retail environment
        - Ensure diverse lighting, angles, and product arrangements
        - Aim for at least 1000 images per product category
        
        ## Data Preparation Steps:
        1. Convert annotations to YOLO format (class x_center y_center width height)
        2. Split data: 70% train, 20% validation, 10% test
        3. Ensure class balance across splits
        4. Apply data augmentation during training
        