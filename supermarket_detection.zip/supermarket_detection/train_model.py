
import os
from ultralytics import YOLO
import torch

def train_retail_model():
    """Train a YOLOv8 model for retail product detection."""
    
    # Check for GPU availability
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Training on device: {device}")
    
    # Load pre-trained YOLOv8 model
    model = YOLO('yolov8m.pt')  # or yolov8l.pt for better accuracy
    
    # Training configuration
    training_args = {
        'data': 'configs/dataset.yaml',
        'epochs': 200,
        'imgsz': 640,  # or 1280 for small objects
        'batch': 16,   # adjust based on GPU memory
        'lr0': 0.01,
        'lrf': 0.01,
        'momentum': 0.937,
        'weight_decay': 0.0005,
        'warmup_epochs': 3,
        'warmup_momentum': 0.8,
        'warmup_bias_lr': 0.1,
        'box': 0.05,
        'cls': 0.5,
        'dfl': 1.5,
        'pose': 12.0,
        'kobj': 1.0,
        'label_smoothing': 0.0,
        'nbs': 64,
        'overlap_mask': True,
        'mask_ratio': 4,
        'dropout': 0.0,
        'val': True,
        'plots': True,
        'save': True,
        'save_period': 10,
        'cache': False,
        'device': device,
        'workers': 8,
        'project': 'results',
        'name': 'retail_detection_v1',
        'exist_ok': False,
        'pretrained': True,
        'optimizer': 'SGD',
        'verbose': True,
        'seed': 0,
        'deterministic': True,
        'single_cls': False,
        'rect': False,
        'cos_lr': False,
        'close_mosaic': 10,
        'resume': False,
        'amp': True,
        'fraction': 1.0,
        'profile': False,
        'freeze': None,
        'multi_scale': False,
        'overlap_mask': True,
        'mask_ratio': 4,
        'dropout': 0.0,
        'val': True,
        'split': 'val',
        'save_json': False,
        'save_hybrid': False,
        'conf': None,
        'iou': 0.7,
        'max_det': 300,
        'half': False,
        'dnn': False,
        'plots': True,
        'source': None,
        'vid_stride': 1,
        'stream_buffer': False,
        'visualize': False,
        'augment': False,
        'agnostic_nms': False,
        'classes': None,
        'retina_masks': False,
        'embed': None,
        'show': False,
        'save_frames': False,
        'save_txt': False,
        'save_conf': False,
        'save_crop': False,
        'show_labels': True,
        'show_conf': True,
        'show_boxes': True,
        'line_width': None,
    }
    
    # Start training
    results = model.train(**training_args)
    
    # Validate the model
    validation_results = model.val()
    
    # Export the model
    model.export(format='onnx')  # Export to ONNX for deployment
    
    return results, validation_results

if __name__ == "__main__":
    train_retail_model()
