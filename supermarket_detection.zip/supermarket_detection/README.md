
# Supermarket Product Detection Training Framework

This framework provides everything needed to train, evaluate, and deploy
YOLOv8 models for supermarket product detection.

## Directory Structure
```
/home/ubuntu/supermarket_detection/
├── datasets/
│   ├── train/images/
│   ├── train/labels/
│   ├── val/images/
│   ├── val/labels/
│   ├── test/images/
│   └── test/labels/
├── configs/
│   └── dataset.yaml
├── models/
├── results/
├── train_model.py
├── evaluate_model.py
├── deploy_model.py
└── dataset_instructions.md
```

## Quick Start

1. **Prepare Data**: Follow instructions in `dataset_instructions.md`
2. **Train Model**: Run `python train_model.py`
3. **Evaluate**: Run `python evaluate_model.py`
4. **Deploy**: Use `deploy_model.py` for inference

## Model Recommendations

- **YOLOv8m**: Good balance of speed and accuracy
- **YOLOv8l**: Better accuracy for complex scenes
- **YOLOv8x**: Best accuracy but slower inference

## Training Tips

- Use image size 640x640 or higher for small objects
- Apply data augmentation (rotation, scaling, color jittering)
- Train for 200-300 epochs
- Use learning rate scheduling
- Monitor validation metrics to prevent overfitting

## Performance Optimization

- Use TensorRT for faster inference on NVIDIA GPUs
- Export to ONNX for cross-platform deployment
- Consider model quantization for edge deployment
- Implement multi-scale testing for better accuracy
