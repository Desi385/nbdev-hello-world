
import cv2
import numpy as np
from ultralytics import YOLO
import matplotlib.pyplot as plt
from pathlib import Path
import json

class ModelEvaluator:
    def __init__(self, model_path):
        self.model = YOLO(model_path)
    
    def evaluate_on_test_set(self, test_images_dir):
        """Evaluate model on test set."""
        test_images = list(Path(test_images_dir).glob("*.jpg"))
        
        results = []
        for img_path in test_images:
            result = self.model(str(img_path))
            results.append({
                'image': str(img_path),
                'detections': len(result[0].boxes) if result[0].boxes else 0,
                'confidence_scores': [float(conf) for conf in result[0].boxes.conf] if result[0].boxes else []
            })
        
        return results
    
    def analyze_performance(self, results):
        """Analyze model performance metrics."""
        total_detections = sum(r['detections'] for r in results)
        avg_detections = total_detections / len(results)
        
        all_confidences = []
        for r in results:
            all_confidences.extend(r['confidence_scores'])
        
        performance = {
            'total_images': len(results),
            'total_detections': total_detections,
            'avg_detections_per_image': avg_detections,
            'avg_confidence': np.mean(all_confidences) if all_confidences else 0,
            'confidence_std': np.std(all_confidences) if all_confidences else 0
        }
        
        return performance
    
    def create_detection_report(self, image_path, output_dir):
        """Create detailed detection report for an image."""
        results = self.model(image_path)
        img = cv2.imread(image_path)
        
        report = {
            'image_path': image_path,
            'image_size': img.shape,
            'detections': []
        }
        
        if results[0].boxes:
            for i, box in enumerate(results[0].boxes):
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls = int(box.cls[0])
                class_name = self.model.names[cls]
                
                detection = {
                    'id': i,
                    'class': class_name,
                    'confidence': conf,
                    'bbox': [x1, y1, x2, y2],
                    'center': [(x1+x2)//2, (y1+y2)//2],
                    'area': (x2-x1) * (y2-y1)
                }
                
                report['detections'].append(detection)
        
        # Save report
        report_path = Path(output_dir) / f"{Path(image_path).stem}_report.json"
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        return report

def main():
    # Example usage
    evaluator = ModelEvaluator('models/best.pt')
    
    # Evaluate on test set
    results = evaluator.evaluate_on_test_set('datasets/test/images')
    performance = evaluator.analyze_performance(results)
    
    print("Performance Metrics:")
    for key, value in performance.items():
        print(f"{key}: {value}")
    
    # Create detailed report for a specific image
    test_image = 'datasets/test/images/sample.jpg'
    if Path(test_image).exists():
        report = evaluator.create_detection_report(test_image, 'results')
        print(f"Detailed report created for {test_image}")

if __name__ == "__main__":
    main()
