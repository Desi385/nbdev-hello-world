
import cv2
import numpy as np
from ultralytics import YOLO
import time
from pathlib import Path

class RetailProductDetector:
    """Production-ready retail product detector."""
    
    def __init__(self, model_path, conf_threshold=0.25):
        self.model = YOLO(model_path)
        self.conf_threshold = conf_threshold
    
    def detect_products(self, image_path):
        """Detect products in an image."""
        start_time = time.time()
        
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        # Run inference
        results = self.model(img, conf=self.conf_threshold)
        
        # Process results
        detections = []
        if results[0].boxes:
            for box in results[0].boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls = int(box.cls[0])
                class_name = self.model.names[cls]
                
                detection = {
                    'class': class_name,
                    'confidence': conf,
                    'bbox': [x1, y1, x2, y2],
                    'center': [(x1+x2)//2, (y1+y2)//2]
                }
                detections.append(detection)
        
        inference_time = time.time() - start_time
        
        return {
            'detections': detections,
            'inference_time': inference_time,
            'image_shape': img.shape
        }
    
    def annotate_image(self, image_path, output_path=None):
        """Annotate image with detections."""
        img = cv2.imread(image_path)
        results = self.model(img, conf=self.conf_threshold)
        
        # Draw annotations
        if results[0].boxes:
            for box in results[0].boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls = int(box.cls[0])
                class_name = self.model.names[cls]
                
                # Draw bounding box
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                
                # Draw label
                label = f"{class_name}: {conf:.2f}"
                cv2.putText(img, label, (x1, y1-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        if output_path:
            cv2.imwrite(output_path, img)
        
        return img
    
    def count_products(self, image_path):
        """Count products by category."""
        result = self.detect_products(image_path)
        if not result:
            return {}
        
        counts = {}
        for detection in result['detections']:
            class_name = detection['class']
            counts[class_name] = counts.get(class_name, 0) + 1
        
        return counts
    
    def get_product_sequence(self, image_path):
        """Get product sequence based on spatial arrangement."""
        result = self.detect_products(image_path)
        if not result:
            return {}
        
        # Group by class
        class_groups = {}
        for detection in result['detections']:
            class_name = detection['class']
            if class_name not in class_groups:
                class_groups[class_name] = []
            class_groups[class_name].append(detection)
        
        # Sort each class by position (top-to-bottom, left-to-right)
        sequences = {}
        for class_name, detections in class_groups.items():
            sorted_detections = sorted(detections, 
                                     key=lambda d: (d['center'][1], d['center'][0]))
            
            sequence = []
            for i, det in enumerate(sorted_detections):
                sequence.append(f"{class_name}_{i+1}({det['center'][0]},{det['center'][1]})")
            
            sequences[class_name] = " -> ".join(sequence)
        
        return sequences

def main():
    # Example usage
    detector = RetailProductDetector('models/best.pt', conf_threshold=0.3)
    
    image_path = 'test_image.jpg'
    
    # Detect products
    results = detector.detect_products(image_path)
    print(f"Found {len(results['detections'])} products")
    
    # Count products
    counts = detector.count_products(image_path)
    print("Product counts:", counts)
    
    # Get sequences
    sequences = detector.get_product_sequence(image_path)
    print("Product sequences:", sequences)
    
    # Annotate image
    annotated_img = detector.annotate_image(image_path, 'annotated_output.jpg')
    print("Annotated image saved")

if __name__ == "__main__":
    main()
